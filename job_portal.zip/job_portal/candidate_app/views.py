from django.shortcuts import render,redirect
from django.http import HttpResponse
from candidate_app.models import Candidate,CandidateDetails
from recruiter_app.models import JobDetail,JobApplied,Recuriter
#this model is used to clear the cache
from django.views.decorators.cache import never_cache

# Create your views here.
@never_cache
def candidate_signup(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        name = request.POST.get('fullname')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        password = request.POST.get('password')

        user = Candidate.objects.create(
            username=username,
            name  = name,
            email = email,
            phone = phone,
            password = password
        )
        return redirect('candidate_login')
    else:
        return render(request,"./candidate_app/c_signup.html")

@never_cache    
def candidate_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
 
        user = Candidate.objects.filter(username=username,password=password).first()

        if user:
            request.session["candidate_id"] = user.id
            request.session["candidate_username"] = user.username
            request.session["candidate_name"] = user.name
            request.session["candidate_email"] = user.email
            request.session["candidate_phone"] = user.phone
            return redirect("candidate_dashboard")
        else:
            return redirect("candidate_login")
    else:
        return render(request,'./candidate_app/c_login.html')

@never_cache  
def candidate_dashboard(request):
    if "candidate_username" not in request.session:
        return redirect('candidate_login')
    username = request.session.get('candidate_username')

    a = JobDetail.objects.all()
    return render(request,'./candidate_app/c_dashboard.html',{'username':username,"a":a})

#add the detaile in candidate dashboard 
'''
{% for i in a %}
<div class="card">
<h1>{{i.companey_name}}</h1>
<h1>{{i.job_role}}</h1>
<h1>Vancency :{{i.vackency}}</h1>
<button>APPLY</button>
{% end_for %}
'''

@never_cache  
def candidate_profile(request):
    if "candidate_username" not in request.session:
        return redirect('candidate_login')
    userid = request.session.get('candidate_id')
    name =  request.session.get('candidate_name')
    email =  request.session.get('candidate_email')

    user = CandidateDetails.objects.filter(user_id = userid).first()

    if user:
        bio = user.bio
        address = user.address
        profile_pic = user.profile_pic
    else:
        bio = None
        address = None
        profile_pic = None

    context = {"username": request.session.get("candidate_username"),
               "name" : name,
               "email":email,
               "bio":bio,
               "address":address,
               "profile_pic":profile_pic}
    return render(request,'./candidate_app/c_profile.html',context)

@never_cache  
def home(request):
    return render(request,'./candidate_app/home.html')

@never_cache 
def candidate_profile_update(request):
    if "candidate_username" not in request.session:
        return redirect("candidate_login")
    
    if request.method == "POST":
        bio = request.POST.get("bio")
        address = request.POST.get("address")
        image = request.FILES.get("image")

        id = request.session.get("candidate_id")
        candidate_id = Candidate.objects.filter(id = id ).first()

        CandidateDetails.objects.update_or_create(
            user = candidate_id,
            defaults={
                "bio":bio,
                "address":address,
                "profile_pic":image
            }
        )
        return redirect("candidate_profile")
    else:
        return render(request,"./candidate_app/profile_update.html ")

@never_cache  
def view_detail(request,id):
    if "candidate_username" not in request.session:
        return redirect("candidate_login")
    job = JobDetail.objects.filter(id = id).first()
    return render(render,"./candidate_app/view_detail.html",{"job":job})

@never_cache  
def apply_job(request,id):
    if "candidate_username" not in request.session:
        return redirect("candidate_login")
    candidate_id = request.session.get("candidate_id")
    candidate = Candidate.objects.filter(id = candidate_id).first()
    job = JobDetail.objects.filter(id = id).first()
    recruiter_id = job.Recuriter.id
    recruiter = Recuriter.objects.filter(id = recruiter_id).first()

    JobApplied.objects.create(
        job_detail = job,
        recuriter = recruiter,
        candidate = candidate,
        scheduled = False
    )
    return redirect("candidate_dashboard")



@never_cache  
def candidate_logout(request):
    request.session.flush()
    return redirect("candidate_login")


def scheduled(request):
    if "candidate_username" not in request.session:
        return redirect("candidate_login")
    user_id = request.session.get("candidate_id")
    print(user_id)
    user = JobApplied.objects.filter(candidate=user_id)
    print(user)
    return render(request,"./candidate_app/result.html",{'user':user})
    

