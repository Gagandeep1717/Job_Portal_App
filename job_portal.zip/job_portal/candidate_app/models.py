from django.db import models
from django.core.validators import FileExtensionValidator #this is for validiation of user input files < some time user upload different types of files so we need to specify which type of file we want >

# Candidate Model
class Candidate(models.Model):
    username = models.CharField(max_length=100)
    name = models.CharField(max_length=200)
    email = models.EmailField()
    phone = models.PositiveBigIntegerField()
    password = models.CharField(max_length=100)
    
    def __str__(self):
        return self.name
    
# Candidate Details Extented Model
class CandidateDetails(models.Model):
    user = models.OneToOneField(Candidate, on_delete=models.CASCADE,)
    bio = models.TextField()
    address = models.TextField()
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    pincode = models.CharField(max_length=20)
    country = models.CharField(max_length=100)
    profile_pic = models.ImageField(upload_to='candidatedp/',null = True)
    resume = models.FileField(upload_to='resume/',null = True, validators=[FileExtensionValidator(allowed_extensions=['pdf','doc'])]) ## this is for validate file type ie parameter <validators>

    def __str__(self):
        return self.user.name