"""
URL configuration for job_portal project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/6.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from recruiter_app import views as r_views
from candidate_app import views as c_views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('r_signup/',r_views.recruiter_signup,name="recruiter_signup"),
    path('r_login/',r_views.recruiter_login,name="recruiter_login"),
    path('r_dashboard/',r_views.recruiter_dashboard,name='recruiter_dashboard'),
    path('r_profile',r_views.recruiter_profile,name="recruiter_profile"),
    path('r_logout',r_views.recruiter_logout,name="recruiter_logout"),
    path('c_signup/',c_views.candidate_signup,name="candidate_signup"),
    path('c_login/',c_views.candidate_login,name="candidate_login"),
    path('c_dashboard/',c_views.candidate_dashboard,name='candidate_dashboard'),
    path('c_profile',c_views.candidate_profile,name="candidate_profile"),
    path('c_logout',c_views.candidate_logout,name="candidate_logout"),
    path('',c_views.home,name="home"),
    path('r_profile_update',r_views.recruiter_profile_update ,name="recruiter_profile_update"),
    path('c_profile_update',c_views.candidate_profile_update ,name="candidate_profile_update"),
    path('r_job_form',r_views.job_details,name="job_details"),
    path('view_detail/<int:id>',c_views.view_detail,name = "view_detail"),
    path('apply_job/<int:id>',c_views.apply_job,name = "apply_job"),
    
    path('applied_job',r_views.applied_job,name = 'applied_job'),
    path('approve/<int:id>',r_views.approve,name = 'approve'),
    path('result',c_views.scheduled, name = 'scheduled')
]

if settings:
    urlpatterns = urlpatterns + static(settings.MEDIA_URL,document_root = settings.MEDIA_ROOT)
