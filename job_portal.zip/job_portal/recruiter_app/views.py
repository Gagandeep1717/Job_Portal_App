from django.shortcuts import render,redirect,get_object_or_404
from django.http import HttpResponse
from recruiter_app.models import Recuriter,RecruiterDetails,JobDetail,JobApplied
#this model is used to clear the cache
from django.views.decorators.cache import never_cache
# Create your views here.

#signup page logics and rediracting to login
@never_cache
def recruiter_signup(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        name = request.POST.get('fullname')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        password = request.POST.get('password')

        user = Recuriter.objects.create(
            username=username,
            name  = name,
            email = email,
            phone = phone,
            password = password
        )
        return redirect('recruiter_login')
    else:
        return render(request,"./recruiter_app/signup.html")

#login page logics that redirect home if credicial is matched and here we are creating the session is user log-ed 
@never_cache
def recruiter_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
 
        user = Recuriter.objects.filter(username=username,password=password).first()

        if user:
            request.session["recruiter_id"] = user.id
            request.session["recruiter_username"] = user.username
            request.session["recruiter_name"] = user.name
            request.session["recruiter_email"] = user.email
            request.session["recruiter_phone"] = user.phone
            return redirect("recruiter_dashboard")
        else:
            return redirect("recruiter_login")
    else:
        return render(request,'./recruiter_app/login.html')


#this fuction will check once agin the data whethere its in session or not then the next process will continue     
@never_cache
def recruiter_dashboard(request):
    if "recruiter_username" not in request.session:
        return redirect('recruiter_login')
    username = request.session.get('recruiter_username')
    a = JobDetail.objects.all()
    return render(request,'./recruiter_app/dashboard.html',{'username':username,'a':a})

# r_profile logic 
@never_cache
def recruiter_profile(request):
    if "recruiter_username" not in request.session:
        return redirect('recruiter_login')
    userid = request.session.get('recruiter_id')
    name =  request.session.get('recruiter_name')
    email =  request.session.get('recruiter_email')

    user = RecruiterDetails.objects.filter(user_id = userid).first()

    if user:
        bio = user.bio
        address = user.address
        profile_pic = user.profile_pic
    else:
        bio = None
        address = None
        profile_pic = None

    context = {"username": request.session.get("recruiter_username"),
               "name" : name,
               "email":email,
               "bio":bio,
               "address":address,
               "profile_pic":profile_pic}
    return render(request,'./recruiter_app/r_profile.html',context)

@never_cache
def recruiter_profile_update(request):
    if "recruiter_username" not in request.session:
        return redirect("recruiter_login")
    
    if request.method == "POST":
        bio = request.POST.get("bio")
        address = request.POST.get("address")
        image = request.FILES.get("image")

        id = request.session.get("recruiter_id")
        recruiter_id = Recuriter.objects.filter(id = id ).first()

        RecruiterDetails.objects.update_or_create(
            user = recruiter_id,
            defaults={
                "bio":bio,
                "address":address,
                "profile_pic":image
            }
        )
        return redirect("recruiter_profile")
    else:
        return render(request,"./recruiter_app/profile_update.html")

@never_cache  
def job_details(request):
    if "recruiter_username" not in request.session:
        return redirect("recruiter_login")

    recruiter_id = request.session.get("recruiter_id")
    recruiter = Recuriter.objects.filter(id=recruiter_id).first()

    if request.method == "POST":
        company_name = request.POST.get("company_name")
        company_address = request.POST.get("company_address")
        company_image = request.FILES.get("company_image")  
        job_role = request.POST.get("job_role")
        job_discription = request.POST.get("job_discription")
        experience = request.POST.get("experience")
        skills_required = request.POST.get("skills")        
        salary = request.POST.get("salary")
        qualification = request.POST.get("qualification")
        vacancies = request.POST.get("vacancy")             
        employment_type = request.POST.get("employment_type")
        job_location = request.POST.get("location")         
        industry_type = request.POST.get("industry")        
        last_date_to_apply = request.POST.get("last_date")  
        hiring_process = request.POST.get("hiring_process")

        JobDetail.objects.create(
            Recuriter=recruiter,              
            company_name=company_name,
            company_address=company_address,
            company_image=company_image,
            job_role=job_role,
            skills_required=skills_required,
            job_discription=job_discription,
            salary=salary,
            experience=experience,
            qualification=qualification,
            vacancies=vacancies,
            job_location=job_location,
            employment_type=employment_type,
            industry_type=industry_type,
            last_date_to_apply=last_date_to_apply,
            hiring_process=hiring_process
        )

        return redirect("recruiter_dashboard")

    return render(request, "./recruiter_app/job_details.html")
    # make sure to create job_details form and make sure to have the same names 
        
def applied_job(request):
    if "recruiter_username" not in request.session:
        return redirect("recruiter_login")
    
    recruiter_id = request.session.get("recruiter_id")

    jobs = JobApplied.objects.filter(recuriter = recruiter_id)
    return render(request,"./recruiter_app/applied_job.html",{"jobs":jobs})
@never_cache
def approve(request,id):
    if "recruiter_username" not in request.session:
        return redirect("recruiter_login")
    job = get_object_or_404(JobApplied,id = id)
    job.scheduled = True
    job.save()
    return redirect("recruiter_dashboard")

#clearing the session data
@never_cache
def recruiter_logout(request):
    request.session.flush()
    return redirect("recruiter_login")

