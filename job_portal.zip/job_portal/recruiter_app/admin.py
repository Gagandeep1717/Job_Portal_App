from django.contrib import admin
from .models import Recuriter

# Register your models here.

admin.site.register(Recuriter)
