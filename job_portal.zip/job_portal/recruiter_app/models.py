from django.db import models
from candidate_app.models import Candidate

# Create your models here.

# Recruiter Model
class Recuriter(models.Model):
    username = models.CharField(max_length=100)
    name = models.CharField(max_length=200)
    email = models.EmailField()
    phone = models.PositiveBigIntegerField()
    password = models.CharField(max_length=100)

    def __str__(self):
        return self.name

# Recruiter Details Extented Model
class RecruiterDetails(models.Model):
    user = models.OneToOneField(Recuriter, on_delete=models.CASCADE,)
    bio = models.TextField()
    address = models.TextField()
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    pincode = models.CharField(max_length=20)
    country = models.CharField(max_length=100)
    profile_pic = models.ImageField(upload_to='recruiterdp/',null = True)

    def __str__(self):
        return self.user.name

# Job Detail Model
class JobDetail(models.Model):
    Recuriter = models.ForeignKey(Recuriter, on_delete=models.CASCADE)
    company_name = models.CharField(max_length=200)
    company_address = models.TextField()
    company_image = models.ImageField(upload_to='companyimage/',null= True)
    job_role = models.CharField(max_length=200)
    skills_required = models.TextField()
    job_discription = models.TextField()
    salary = models.CharField(max_length=200)
    experience = models.CharField(max_length=200)
    qualification = models.CharField(max_length=200)
    vacancies = models.CharField(max_length=100)
    job_location = models.CharField(max_length=200)
    employment_type = models.CharField(max_length=200)
    industry_type = models.CharField(max_length=200)
    job_posted_on = models.DateField(auto_now_add=True)
    last_date_to_apply = models.DateField()
    hiring_process = models.TextField()

    def __str__(self):
        return self.job_role
    
class JobApplied(models.Model):
    job_detail = models.ForeignKey(JobDetail, on_delete=models.CASCADE)
    recuriter = models.ForeignKey(Recuriter,on_delete=models.CASCADE)
    candidate = models.ForeignKey(Candidate, on_delete=models.CASCADE)
    scheduled = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.candidate.name} applied for {self.job_detail.job_role}"